package com.snebot.fbmoll.ui;

public enum ControlPanelAction {
    PLAY, PAUSE, STOP, RESTART
}

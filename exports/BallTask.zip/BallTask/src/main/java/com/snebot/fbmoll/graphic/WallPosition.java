package com.snebot.fbmoll.graphic;

public enum WallPosition {
    TOP, RIGHT, BOTTOM, LEFT, NONE
}

package com.snebot.fbmoll.ui;

import com.snebot.fbmoll.graphic.VisibleObject;

import java.util.List;

public interface ViewerDelegate {
    List<VisibleObject> getVisibleObjects();
}

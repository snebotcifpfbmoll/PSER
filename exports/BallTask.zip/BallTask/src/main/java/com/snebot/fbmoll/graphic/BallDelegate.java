package com.snebot.fbmoll.graphic;

public interface BallDelegate {
    boolean canMove(Ball ball);
}
